# Codelab de introducción

Este es un ejemplo de codelab que pasa todas las pruebas.

No termine un parrafo con espacios en blanca.

```js
console.log("Esto es un codelab")
```
